#ifndef CORE_ARCH_CPU_H
#define CORE_ARCH_CPU_H

#include "CpuRegister.h"
#include "CpuFeature.h"

#endif


#include "core/arch/CpuFeature.h"
#include "logging/logging.h"

void CpuFeatures::ClearCache(void *start, void *end) {
  UNIMPLEMENTED();
}
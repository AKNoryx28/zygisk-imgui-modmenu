#pragma once

static int glWidth, glHeight;
